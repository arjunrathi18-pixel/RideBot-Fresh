package com.ridebot.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val MC = "com.ridebot/control"
    private val EC = "com.ridebot/logs"
    private val PREFS = "ridebot_prefs"
    private var logSink: EventChannel.EventSink? = null
    private var logReceiver: BroadcastReceiver? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, MC)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "setEnabled" -> {
                        prefs().edit().putBoolean("automation_enabled", call.argument("enabled")!!).apply()
                        result.success(null)
                    }
                    "savePlatformConfig" -> {
                        val p = call.argument<String>("platform")!!
                        prefs().edit().apply {
                            putBoolean("${p}_enabled", call.argument("enabled")!!)
                            putFloat("${p}_min_price", (call.argument<Double>("minPrice")!!).toFloat())
                            putFloat("${p}_max_price", (call.argument<Double>("maxPrice")!!).toFloat())
                            putFloat("${p}_min_km", (call.argument<Double>("minKm")!!).toFloat())
                            putFloat("${p}_max_km", (call.argument<Double>("maxKm")!!).toFloat())
                            putString("${p}_ride_types", call.argument<String>("rideTypes") ?: "")
                            apply()
                        }
                        result.success(null)
                    }
                    "saveGlobalSettings" -> {
                        prefs().edit().apply {
                            putBoolean("auto_start_on_boot", call.argument("autoStart")!!)
                            putBoolean("night_mode", call.argument("nightMode")!!)
                            putBoolean("sound_on_accept", call.argument("soundOnAccept")!!)
                            putBoolean("surge_auto_accept", call.argument("surgeAccept")!!)
                            apply()
                        }
                        result.success(null)
                    }
                    "saveLocations" -> {
                        prefs().edit()
                            .putString("saved_locations", call.argument<String>("locations") ?: "[]")
                            .putBoolean("location_filter_enabled", call.argument("locationFilterEnabled")!!)
                            .apply()
                        result.success(null)
                    }
                    "updateDriverLocation" -> {
                        prefs().edit()
                            .putFloat("driver_lat", (call.argument<Double>("lat")!!).toFloat())
                            .putFloat("driver_lng", (call.argument<Double>("lng")!!).toFloat())
                            .apply()
                        result.success(null)
                    }
                    "isAccessibilityEnabled" -> result.success(isAccessibilityOn())
                    "hasOverlayPermission" -> result.success(
                        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
                    )
                    "openAccessibilitySettings" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        result.success(null)
                    }
                    "openOverlayPermission" -> {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        result.success(null)
                    }
                    "getSettings" -> result.success(buildSettingsMap())
                    else -> result.notImplemented()
                }
            }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EC)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(args: Any?, sink: EventChannel.EventSink?) {
                    logSink = sink
                    val filter = IntentFilter().apply {
                        addAction("com.ridebot.LOG_UPDATE")
                        addAction("com.ridebot.SERVICE_STATUS")
                    }
                    logReceiver = object : BroadcastReceiver() {
                        override fun onReceive(c: Context, i: Intent) {
                            logSink?.success(mapOf(
                                "type" to (i.getStringExtra("type") ?: "info"),
                                "msg"  to (i.getStringExtra("msg")  ?: ""),
                                "time" to i.getLongExtra("time", 0)
                            ))
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        registerReceiver(logReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
                    else
                        registerReceiver(logReceiver, filter)
                }
                override fun onCancel(args: Any?) {
                    logSink = null
                    try { logReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) {}
                }
            })
    }

    private fun isAccessibilityOn(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.id.contains("ridebot") }
    }
    private fun prefs(): SharedPreferences = getSharedPreferences(PREFS, MODE_PRIVATE)
    private fun buildSettingsMap(): Map<String, Any> {
        val p = prefs()
        val m = mutableMapOf<String, Any>()
        m["automation_enabled"]      = p.getBoolean("automation_enabled", false)
        m["auto_start_on_boot"]      = p.getBoolean("auto_start_on_boot", false)
        m["night_mode"]              = p.getBoolean("night_mode", false)
        m["sound_on_accept"]         = p.getBoolean("sound_on_accept", true)
        m["surge_auto_accept"]       = p.getBoolean("surge_auto_accept", true)
        m["location_filter_enabled"] = p.getBoolean("location_filter_enabled", false)
        m["saved_locations"]         = p.getString("saved_locations", "[]")!!
        for (pl in listOf("rapido","ola","uber")) {
            m["${pl}_enabled"]    = p.getBoolean("${pl}_enabled", false)
            m["${pl}_min_price"]  = p.getFloat("${pl}_min_price", 50f)
            m["${pl}_max_price"]  = p.getFloat("${pl}_max_price", 3000f)
            m["${pl}_min_km"]     = p.getFloat("${pl}_min_km", 0f)
            m["${pl}_max_km"]     = p.getFloat("${pl}_max_km", 200f)
            m["${pl}_ride_types"] = p.getString("${pl}_ride_types", "")!!
        }
        return m
    }
    override fun onDestroy() {
        super.onDestroy()
        try { logReceiver?.let { unregisterReceiver(it) } } catch (e: Exception) {}
    }
}
